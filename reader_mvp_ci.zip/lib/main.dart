import 'dart:io';
import 'dart:async';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'ocr_service.dart';
import 'auto_scan.dart';

late List<CameraDescription> _cameras;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  _cameras = await availableCameras();
  runApp(const ReaderApp());
}

class ReaderApp extends StatelessWidget {
  const ReaderApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(useMaterial3: true, brightness: Brightness.dark),
      home: const ReaderHome(),
    );
  }
}

class ReaderHome extends StatefulWidget {
  const ReaderHome({super.key});
  @override
  State<ReaderHome> createState() => _ReaderHomeState();
}

class _ReaderHomeState extends State<ReaderHome> {
  CameraController? controller;
  final tts = FlutterTts();
  final ocr = OcrService();
  String lastText = '';
  bool busy = false;
  bool autoMode = true;
  AutoScanner? scanner;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    await tts.setLanguage('ja-JP');
    await tts.setSpeechRate(0.9);
    await tts.setPitch(1.0);

    final cam = _cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => _cameras.first,
    );
    controller = CameraController(cam, ResolutionPreset.medium, enableAudio: false);
    await controller!.initialize();

    scanner = AutoScanner(controller!, minIntervalMs: 1500, onCapture: _onAutoCapture);
    if (autoMode) scanner!.start();

    if (!mounted) return;
    setState(() {});
  }

  @override
  void dispose() {
    scanner?.stop();
    controller?.dispose();
    tts.stop();
    super.dispose();
  }

  Future<void> _onAutoCapture(XFile file) async {
    if (busy) return;
    setState(() => busy = true);
    try {
      final dir = await getTemporaryDirectory();
      final toPath = p.join(dir.path, 'auto_${DateTime.now().millisecondsSinceEpoch}.jpg');
      await File(file.path).copy(toPath);

      String text = await ocr.extractByColumns(toPath);
      if (text.trim().isEmpty) {
        text = await ocr.extractBest(toPath);
      }

      if (text.isNotEmpty && text != lastText) {
        lastText = text;
        await tts.speak(text);
      }
    } catch (_) {
      await tts.speak('エラーが発生しました。');
    } finally {
      setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final camReady = controller?.value.isInitialized ?? false;
    return Scaffold(
      body: SafeArea(
        child: Stack(
          children: [
            if (camReady) CameraPreview(controller!) else const Center(child: CircularProgressIndicator()),
            IgnorePointer(
              child: Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.8,
                  height: MediaQuery.of(context).size.height * 0.5,
                  decoration: BoxDecoration(
                    border: Border.all(width: 3, color: Colors.white70),
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Expanded(
                      child: FilledButton(
                        onPressed: () {
                          setState(() => autoMode = !autoMode);
                          if (autoMode) {
                            scanner?.start();
                          } else {
                            scanner?.stop();
                          }
                        },
                        child: Text(autoMode ? '連続スキャン: ON' : '連続スキャン: OFF'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
