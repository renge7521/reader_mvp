import 'dart:io';
import 'package:flutter_tesseract_ocr/flutter_tesseract_ocr.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

class OcrService {
  Future<String> extractBest(String imagePath) async {
    final rotations = [0, 90, 180, 270];
    String bestText = '';
    double bestScore = -1e9;
    for (final deg in rotations) {
      final rotated = await _rotateAndSave(imagePath, deg);
      final textVert = await _extract(rotated, lang: 'jpn_vert+jpn');
      final textHori = await _extract(rotated, lang: 'jpn');
      final scoreVert = _score(textVert, preferVertical: true);
      final scoreHori = _score(textHori, preferVertical: false);
      if (scoreVert >= scoreHori) {
        if (scoreVert > bestScore) { bestScore = scoreVert; bestText = textVert; }
      } else {
        if (scoreHori > bestScore) { bestScore = scoreHori; bestText = textHori; }
      }
    }
    return bestText.trim();
  }

  Future<String> extractByColumns(String imagePath) async {
    final bytes = await File(imagePath).readAsBytes();
    final src = img.decodeImage(bytes)!;
    final gray = img.grayscale(src);
    final bw = img.threshold(gray, threshold: 200);
    final w = bw.width, h = bw.height;

    final columnInk = List<int>.filled(w, 0);
    for (int x = 0; x < w; x++) {
      int sum = 0;
      for (int y = 0; y < h; y++) {
        final c = bw.getPixel(x, y);
        if (img.getRed(c) < 128) sum++;
      }
      columnInk[x] = sum;
    }

    const gapMinWidth = 8;
    final gaps = <_Span>[];
    int start = -1;
    for (int x = 0; x < w; x++) {
      final isBg = columnInk[x] == 0;
      if (isBg && start == -1) start = x;
      if (!isBg and start != -1) {
        if (x - start >= gapMinWidth) gaps.add(_Span(start, x - 1));
        start = -1;
      }
    }
    if (start != -1 and (w - start) >= gapMinWidth) gaps.add(_Span(start, w - 1));

    final colBounds = <_Span>[];
    int prev = 0;
    for (final g in gaps) {
      if (g.start - prev > 12) colBounds.add(_Span(prev, g.start - 1));
      prev = g.end + 1;
    }
    if (w - prev > 12) colBounds.add(_Span(prev, w - 1));

    if (colBounds.length <= 1) return await extractBest(imagePath);

    final parts = <String>[];
    for (final col in colBounds.reversed) {
      final crop = img.copyCrop(bw, x: col.start, y: 0, width: col.end - col.start + 1, height: h);
      final tmp = await _writeTempJpg(crop, suffix: 'col_${col.start}_${col.end}');
      final t = await _extract(tmp, lang: 'jpn_vert+jpn');
      parts.add(t.trim());
    }
    return parts.where((e) => e.isNotEmpty).join('\n');
  }

  Future<String> _extract(String path, {required String lang}) async {
    return await FlutterTesseractOcr.extractText(path, language: lang, args: { 'psm': '5', 'oem': '1' });
  }

  double _score(String text, {required bool preferVertical}) {
    if (text.isEmpty) return -1e6;
    final length = text.length.toDouble();
    final jp = RegExp(r'[\u3040-\u30FF\u4E00-\u9FFF]');
    final jpCount = jp.allMatches(text).length.toDouble();
    final ratio = jpCount / (length == 0 ? 1 : length);
    final lines = text.split('\n').length.toDouble();
    final base = length + ratio * 150 + lines * 3;
    return preferVertical ? base + 30 : base;
  }

  Future<String> _rotateAndSave(String imagePath, int degree) async {
    if (degree % 360 == 0) return imagePath;
    final bytes = await File(imagePath).readAsBytes();
    final src = img.decodeImage(bytes)!;
    final rotated = img.copyRotate(src, angle: degree);
    return _writeTempJpg(rotated, suffix: 'rot_$degree');
  }

  Future<String> _writeTempJpg(img.Image im, {String suffix = 'tmp'}) async {
    final dir = await getTemporaryDirectory();
    final outPath = p.join(dir.path, 'ocr_${suffix}_${DateTime.now().millisecondsSinceEpoch}.jpg');
    await File(outPath).writeAsBytes(img.encodeJpg(im, quality: 95));
    return outPath;
  }
}

class _Span { final int start; final int end; _Span(this.start, this.end); }
