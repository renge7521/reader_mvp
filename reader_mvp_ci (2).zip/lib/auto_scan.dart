import 'dart:async';
import 'package:camera/camera.dart';

class AutoScanner {
  final CameraController controller;
  final int minIntervalMs;
  final Future<void> Function(XFile) onCapture;
  Timer? _timer;
  bool _running = false;
  bool _capturing = false;

  AutoScanner(this.controller, {required this.minIntervalMs, required this.onCapture});

  void start() {
    if (_running) return;
    _running = true;
    _timer = Timer.periodic(Duration(milliseconds: minIntervalMs), (t) async {
      if (!_running || _capturing) return;
      if (!controller.value.isInitialized) return;
      try {
        _capturing = true;
        final file = await controller.takePicture();
        await onCapture(file);
      } finally {
        _capturing = false;
      }
    });
  }

  void stop() {
    _running = false;
    _timer?.cancel();
    _timer = null;
  }
}
